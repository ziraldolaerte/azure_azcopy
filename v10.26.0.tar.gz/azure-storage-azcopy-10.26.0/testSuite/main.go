package main

import (
	"github.com/Azure/azure-storage-azcopy/v10/testSuite/cmd"
)

func main() {
	cmd.Execute()
}
