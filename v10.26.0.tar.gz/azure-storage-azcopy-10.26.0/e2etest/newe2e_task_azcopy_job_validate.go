package e2etest

/*
ValidatePlanFiles

todo: Determine an interface for this. We could have it act like ValidateResource where it will validate against a resource definition.
*/
func ValidatePlanFiles(sm *ScenarioVariationManager, plan *AzCopyJobPlan, todo any) {}
